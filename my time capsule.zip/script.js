
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('memoryForm');
  const memoryList = document.getElementById('memoryList');
  const filterCategory = document.getElementById('filterCategory');
  const themeToggle = document.getElementById('themeToggle');

  // ensure unlockDate cannot be set to a past date by default
  const unlockInput = document.getElementById('unlockDate');
  const todayISO = new Date().toISOString().split('T')[0];
  unlockInput.setAttribute('min', todayISO);

  // Load initial memories
  loadMemories();

  // Submit memory
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const title = document.getElementById('title').value.trim();
    const description = document.getElementById('description').value.trim();
    const category = document.getElementById('category').value;
    const unlockDate = document.getElementById('unlockDate').value;

    if (!title || !description || !category || !unlockDate) {
      alert('Please fill all fields');
      return;
    }

    // simple date validation
    if (new Date(unlockDate + 'T00:00:00') < new Date(todayISO + 'T00:00:00')) {
      alert('Unlock date cannot be in the past.');
      return;
    }

    const memory = {
      id: Date.now(),
      title,
      description,
      category,
      unlockDate
    };

    saveMemory(memory);
    form.reset();
    // reset min again (form.reset clears it on some browsers)
    unlockInput.setAttribute('min', todayISO);
    loadMemories();
  });

  // Filter by category
  filterCategory.addEventListener('change', () => {
    loadMemories(filterCategory.value);
  });

  // Dark mode toggle (persisted in localStorage)
  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    themeToggle.textContent = document.body.classList.contains('dark-mode') ? 'light-mode' : 'dark-mode';
    localStorage.setItem('capsule-dark', document.body.classList.contains('dark-mode'));
  });

  // apply persisted theme
  if (localStorage.getItem('capsule-dark') === 'true') {
    document.body.classList.add('dark-mode');
    themeToggle.textContent = 'light-mode';
  }

  // update countdowns every 30 seconds and re-render unlocked cards
  let countdownInterval = setInterval(updateCountdownsAndMaybeUnlock, 30 * 1000);

  // Save memory to localStorage
  function saveMemory(memory) {
    const memories = JSON.parse(localStorage.getItem('memories')) || [];
    memories.push(memory);
    localStorage.setItem('memories', JSON.stringify(memories));
  }

  // Load and display memories
  function loadMemories(filter = "All") {
    memoryList.innerHTML = '';
    const memories = JSON.parse(localStorage.getItem('memories')) || [];
    const today = new Date().toISOString().split('T')[0];

    // Optionally sort by unlock date
    memories.sort((a,b) => a.unlockDate.localeCompare(b.unlockDate));

    memories.forEach(memory => {
      if (filter !== "All" && memory.category !== filter) return;

      const card = document.createElement('div');
      card.className = 'card';
      const isUnlocked = memory.unlockDate <= today;

      const h3 = document.createElement('h3');
      h3.textContent = memory.title;
      card.appendChild(h3);

      if (!isUnlocked) {
        card.classList.add('locked');
        const p = document.createElement('p');
        p.innerHTML = `<em>Locked until ${memory.unlockDate}</em>`;
        card.appendChild(p);

        const countdown = document.createElement('p');
        countdown.className = 'countdown';
        countdown.dataset.date = memory.unlockDate;
        card.appendChild(countdown);
      } else {
        const p = document.createElement('p');
        p.textContent = memory.description;
        card.appendChild(p);

        const smallUnlock = document.createElement('small');
        smallUnlock.textContent = `Unlocked on: ${memory.unlockDate}`;
        card.appendChild(smallUnlock);
      }

      const smallCat = document.createElement('small');
      smallCat.textContent = `Category: ${memory.category}`;
      card.appendChild(smallCat);

      // actions
      const actions = document.createElement('div');
      actions.className = 'actions';

      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.title = 'Edit';
      editBtn.textContent = '✏️';
      editBtn.addEventListener('click', () => editMemory(memory.id));

      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.title = 'Delete';
      delBtn.textContent = '🗑️';
      delBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to delete this memory?')) {
          deleteMemory(memory.id);
        }
      });

      actions.appendChild(editBtn);
      actions.appendChild(delBtn);
      card.appendChild(actions);

      memoryList.appendChild(card);
    });

    updateCountdownsAndMaybeUnlock();
  }

  // Updates countdown elements and re-renders when something becomes unlocked
  function updateCountdownsAndMaybeUnlock() {
    const countdownElements = document.querySelectorAll('.countdown');
    const now = new Date();
    let unlockedFound = false;

    countdownElements.forEach(el => {
      const unlockDate = new Date(el.dataset.date + 'T00:00:00');
      const diff = unlockDate - now;

      if (diff > 0) {
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
        const minutes = Math.floor((diff / (1000 * 60)) % 60);
        el.textContent = `⏳ Unlocks in ${days}d ${hours}h ${minutes}m`;
      } else {
        el.textContent = '🔓 Now Unlocked!';
        unlockedFound = true;
      }
    });

    if (unlockedFound) {
      // re-render so unlocked cards show their content
      loadMemories(filterCategory.value || 'All');
    }
  }

  // Delete a memory
  function deleteMemory(id) {
    let memories = JSON.parse(localStorage.getItem('memories')) || [];
    memories = memories.filter(m => m.id !== id);
    localStorage.setItem('memories', JSON.stringify(memories));
    loadMemories(filterCategory.value || 'All');
  }

  // Edit a memory
  function editMemory(id) {
    const memories = JSON.parse(localStorage.getItem('memories')) || [];
    const memory = memories.find(m => m.id === id);
    if (!memory) return;

    document.getElementById('title').value = memory.title;
    document.getElementById('description').value = memory.description;
    document.getElementById('category').value = memory.category;
    document.getElementById('unlockDate').value = memory.unlockDate;

    // remove the old entry so saving will create a fresh one
    deleteMemory(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // cleanup when leaving
  window.addEventListener('beforeunload', () => {
    clearInterval(countdownInterval);
  });
});
